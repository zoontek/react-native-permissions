#import "RNPermissions.h"

@interface RNPermissionHandlerReminders : NSObject<RNPermissionHandler>

@end
