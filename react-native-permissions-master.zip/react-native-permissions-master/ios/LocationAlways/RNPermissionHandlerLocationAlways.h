#import "RNPermissions.h"

@interface RNPermissionHandlerLocationAlways : NSObject<RNPermissionHandler>

@end
