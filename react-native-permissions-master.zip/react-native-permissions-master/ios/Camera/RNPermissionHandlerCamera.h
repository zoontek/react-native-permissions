#import "RNPermissions.h"

@interface RNPermissionHandlerCamera : NSObject<RNPermissionHandler>

@end
