#import "RNPermissions.h"

@interface RNPermissionHandlerMicrophone : NSObject<RNPermissionHandler>

@end
