#import "RNPermissions.h"

@interface RNPermissionHandlerMotion : NSObject<RNPermissionHandler>

@end
