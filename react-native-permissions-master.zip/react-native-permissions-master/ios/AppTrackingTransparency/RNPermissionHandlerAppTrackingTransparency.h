#import "RNPermissions.h"

@interface RNPermissionHandlerAppTrackingTransparency : NSObject<RNPermissionHandler>

@end
