#import "RNPermissions.h"

@interface RNPermissionHandlerCalendars : NSObject<RNPermissionHandler>

@end
