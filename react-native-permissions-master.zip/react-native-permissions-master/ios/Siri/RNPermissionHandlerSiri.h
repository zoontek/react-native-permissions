#import "RNPermissions.h"

@interface RNPermissionHandlerSiri : NSObject<RNPermissionHandler>

@end
