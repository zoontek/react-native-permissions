#import "RNPermissions.h"

@interface RNPermissionHandlerBluetoothPeripheral : NSObject<RNPermissionHandler>

@end
