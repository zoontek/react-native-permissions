#import "RNPermissions.h"

@interface RNPermissionHandlerLocationWhenInUse : NSObject<RNPermissionHandler>

@end
