#import "RNPermissions.h"

@interface RNPermissionHandlerPhotoLibraryAddOnly : NSObject<RNPermissionHandler>

@end
