#import "RNPermissions.h"

@interface RNPermissionHandlerStoreKit : NSObject<RNPermissionHandler>

@end
