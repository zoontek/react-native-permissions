#import "RNPermissions.h"

@interface RNPermissionHandlerMediaLibrary : NSObject<RNPermissionHandler>

@end
