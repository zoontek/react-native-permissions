#import "RNPermissions.h"

@interface RNPermissionHandlerContacts : NSObject<RNPermissionHandler>

@end
