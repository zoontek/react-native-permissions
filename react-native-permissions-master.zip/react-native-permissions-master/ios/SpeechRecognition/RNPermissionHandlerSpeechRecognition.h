#import "RNPermissions.h"

@interface RNPermissionHandlerSpeechRecognition : NSObject<RNPermissionHandler>

@end
