#import "RNPermissions.h"

@interface RNPermissionHandlerFaceID : NSObject<RNPermissionHandler>

@end
