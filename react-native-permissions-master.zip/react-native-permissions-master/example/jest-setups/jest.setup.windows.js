/* eslint-disable no-undef */
platform = 'windows';
