#pragma once

#include "App.xaml.g.h"

namespace winrt::Example::implementation
{
    struct App : AppT<App>
    {
        App() noexcept;
    };
} // namespace winrt::Example::implementation


